Open a BMP image from file
"""""""""""""""""""""""""""""""""""""""""""""""

.. lv_example:: libs/bmp/lv_example_bmp_1
  :language: c

